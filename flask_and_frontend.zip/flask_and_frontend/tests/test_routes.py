def test_get_products_empty(client):
    response = client.get("/api/products")
    assert response.status_code == 200
    assert response.json == []

def test_create_product(client):
    new_product = {
        "name": "Test Product",
        "description": "A test product",
        "price": 10.99,
        "stock": 100
    }
    response = client.post("/api/products", json=new_product)
    assert response.status_code == 201
    assert response.json["name"] == "Test Product"

def test_get_products(client):
    # Add a product first
    client.post("/api/products", json={
        "name": "Test Product 1",
        "description": "Another product",
        "price": 20.99,
        "stock": 50
    })

    response = client.get("/api/products")
    assert response.status_code == 200
    assert len(response.json) == 1
    assert response.json[0]["name"] == "Test Product 1"
