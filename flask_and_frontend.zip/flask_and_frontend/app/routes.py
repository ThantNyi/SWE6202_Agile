from flask import Blueprint, jsonify, request
from .models import User, Product  # Corrected: Changed 'Products' to 'Product'
from . import db
from .schemas import UserSchema, ProductSchema

main_bp = Blueprint('main', __name__)

# User routes
@main_bp.route('/api/users', methods=['POST'])
def create_user():
    user_schema = UserSchema()
    try:
        user_data = user_schema.load(request.json)
        new_user = User(**user_data)
        db.session.add(new_user)
        db.session.commit()
        return user_schema.dump(new_user), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Product routes
@main_bp.route('/api/products', methods=['GET', 'POST'])
def products():
    product_schema = ProductSchema()
    if request.method == 'GET':
        products = Product.query.all()
        return jsonify(product_schema.dump(products, many=True)), 200
    elif request.method == 'POST':
        try:
            product_data = product_schema.load(request.json)
            new_product = Product(**product_data)
            db.session.add(new_product)
            db.session.commit()
            return product_schema.dump(new_product), 201
        except Exception as e:
            return jsonify({"error": str(e)}), 400
