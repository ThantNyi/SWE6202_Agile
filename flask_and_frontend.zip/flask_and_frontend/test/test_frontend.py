import time
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

# Set up the WebDriver
@pytest.fixture
def browser():
    options = Options()
    options.add_argument("--headless")  # Run tests without opening a browser window
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920x1080")

    service = Service('/path/to/chromedriver')  # Replace with the path to your WebDriver
    driver = webdriver.Chrome(service=service, options=options)

    yield driver
    driver.quit()

# Test: Verify that the home page loads
def test_home_page(browser):
    browser.get("http://127.0.0.1:5000/")  # URL of your Flask front-end
    assert "CleanSMRs" in browser.title

# Test: Verify navigation to the products page
def test_products_page_navigation(browser):
    browser.get("http://127.0.0.1:5000/")
    time.sleep(2)

    # Find and click the 'Products' link
    products_link = browser.find_element(By.LINK_TEXT, "Products")
    products_link.click()
    time.sleep(2)

    # Verify that the URL changed
    assert "products" in browser.current_url

# Test: Verify adding a product to the cart
def test_add_product_to_cart(browser):
    browser.get("http://127.0.0.1:5000/products")
    time.sleep(2)

    # Simulate clicking the "Add to Cart" button
    add_to_cart_button = browser.find_element(By.XPATH, "//button[contains(text(), 'Add to Cart')]")
    add_to_cart_button.click()
    time.sleep(2)

    # Verify the cart has updated
    cart_count = browser.find_element(By.ID, "cart-count")
    assert cart_count.text == "1"
